# Peak Gear AI Lakehouse Resource Manager source

This directory is the root of the OCI Resource Manager stack. The customer ZIP
must contain these files at its root, not inside another folder.

## Customer input contract

Resource Manager provides `tenancy_ocid`, `current_user_ocid`, `region`, and
the selected compartment from the active stack context. The customer supplies:

- Location, availability domain, application and administration access CIDRs, plus optional paired SSH key and SSH CIDR values.
- A direct HTTPS Object Storage URL for the approved GGSA `V1054826-01.zip` archive.
- Oracle Container Registry username and Auth Token.
- An existing OCI API key and Customer Secret Key owned by the signed-in user.

The reviewed VM, paid Autonomous Database, and AI defaults are used unless
**Show advanced options** is enabled. GGSA, Gravitino, and GoldenGate access is
restricted to the required administration-tools CIDR.

The reviewed Peak Gear and Gravitino locations are maintained in
`approved-artifacts.json`. GGSA is a required sensitive Resource Manager input;
use the same approved direct Object Storage link supplied to the local deployment.

The OCI API key is required because the current Peak Gear application creates
OCI Generative AI database profiles with API-key authentication. The Customer
Secret Key is required because the approved Gravitino build uses OCI Object
Storage through its S3-compatible API. These are runtime credentials, not
software download locations, and must never be embedded in the release ZIP.

No local OCI profile, Packer file, `.tfvars` file, or manually generated
runtime credential belongs in this directory or the release ZIP.

## Deployment lifecycle

1. Terraform creates the network, ADB, private Object Storage bucket, and
   application VM.
2. Cloud-init receives deployment-specific values through protected instance
   metadata and writes a root-only bootstrap environment. Terraform gzip
   compresses cloud-init so the request stays safely below OCI's 32,000-byte
   instance metadata limit.
3. The VM downloads the approved software, loads ADB, and starts the Podman
   services.
4. The VM publishes a credential-free status callback to the stack-owned
   bucket.
5. Resource Manager Apply waits for ADB loading and every declared service
   check. It fails when bootstrap reports a failure or times out.
6. First boot removes registry credentials, archive URLs, wallets, and source
   archives that are no longer needed.
7. Resource Manager Destroy removes the workload. It does not modify the
   customer-supplied OCI credentials.

The stack carries an explicit bootstrap revision. Updating to a release with a
new revision replaces only the application VM so first boot runs again, while
Terraform retains compatible database, network, and Object Storage resources.

## Validate the source

```powershell
terraform fmt -check -recursive
terraform init -backend=false
terraform validate
```

The Linux bootstrap scripts can be syntax-checked with:

```bash
bash -n scripts/bootstrap_lakehouse_vm.sh
bash -n scripts/wait_for_bootstrap_callback.sh
```

## Build the customer ZIP

Windows:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\package-resource-manager.ps1
```

macOS or Linux:

```bash
bash ./package-resource-manager.sh
```

The output is
`../peakgear-ai-lakehouse-resource-manager-v22.zip`.

Both packagers reject Terraform state, variable files, local OCI configuration,
environment files, wallets, private keys, concrete OCI resource OCIDs,
unreviewed pre-authenticated request URLs, and generated artifacts. The only
permitted pre-authenticated URLs are the reviewed central artifact locations in
`approved-artifacts.json`. The packagers also verify the ZIP structure required
by Resource Manager.
